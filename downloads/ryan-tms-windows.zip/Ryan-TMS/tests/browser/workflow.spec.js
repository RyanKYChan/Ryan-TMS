import { test, expect } from '@playwright/test';
import { readFileSync } from 'node:fs';
import { parseGrid } from '../../client/src/importer.js';
test.beforeEach(async({page,request})=>{
  const response=await request.post('/api/projects',{data:{name:`Browser test ${Date.now()}`,customer:'TEST DATA',target:400}});
  const p=await response.json();expect(response.status()).toBe(201);
  await page.addInitScript(id=>localStorage.setItem('ryan-project',id),p.id);
  await page.goto('/');await expect(page.getByRole('heading',{name:'Operations overview'})).toBeVisible();
  await expect(page.getByText('Your next movement')).toBeVisible();
});
test('Paste sheet → build load → assign → depart → deliver → reload → export',async({page})=>{
  const browserErrors=[];page.on('pageerror',e=>browserErrors.push(e.message));
  await page.getByRole('button',{name:'Import units',exact:true}).click();
  await page.getByLabel('Packing list name *',{exact:true}).fill('MAXUS · Vessel 01');
  await page.getByLabel('Paste sheet data').fill('Brand\tVIN\tModel\tReference\tComments\tPort Comment\tPOL-COUNTRY\tPOL-CTY\tPOL-ZIPCODE\tPOD-COUNTRY\tPOD-CITY\tDealer name\tcarrier\tTruck plate\tPrice(EUR)\tT1\nMAXUS\tLSFAM11A1RA000001\tDeliver 9\tREF001\tKeys checked\tAt port\tBE\tZeebrugge\t8380\tNL\tUtrecht\tDealer A\tCarrier A\tAB-123\t95,50\tYes\nMAXUS\tLSFAM11A1RA000002\tMIFA 9\tREF002\t\t\tBE\tZeebrugge\t8380\tNL\tUtrecht\tDealer B\tCarrier A\tAB-123\t105,50\tNo');
  await page.getByRole('button',{name:'Review data'}).click();
  await expect(page.getByText('Rows to fix')).toBeVisible();
  await page.getByRole('button',{name:'Import 2 units',exact:true}).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button',{name:/^Load builds/}).click();await page.getByRole('button',{name:'New load',exact:true}).click();
  await page.getByLabel('Load reference *',{exact:true}).fill('MX-001');await page.getByLabel('Carrier',{exact:true}).fill('Carrier A');
  await page.getByLabel('Truck plate',{exact:true}).fill('AB-123');await page.getByLabel('Origin / POL city').fill('Zeebrugge');await page.getByLabel('Destination / POD city').fill('Utrecht');
  await page.getByLabel('ETD · Estimated departure',{exact:true}).fill('2026-10-12T08:00');await page.getByLabel('ETA · Estimated arrival',{exact:true}).fill('2026-10-13T12:00');
  await page.getByRole('button',{name:'Create load',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button',{name:/^Unit register/}).click();await page.getByRole('checkbox',{name:'Select this page'}).check();
  await page.getByRole('button',{name:'Assign to load',exact:true}).click();await page.getByLabel('Load *',{exact:true}).selectOption({label:'MX-001 · 8 spaces'});
  await page.getByRole('button',{name:'Assign vehicles'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('tbody .badge.ready')).toHaveCount(2);
  await page.getByRole('button',{name:'MX-001',exact:true}).first().click();
  await page.getByLabel('Actual date and time',{exact:true}).fill('2026-10-12T09:00');await page.getByRole('button',{name:'Record',exact:true}).click();
  await expect(page.getByRole('dialog').locator('tbody .badge.in_transit')).toHaveCount(2);
  await page.getByLabel('Record for units missing this milestone').selectOption('ata');await page.getByLabel('Actual date and time',{exact:true}).fill('2026-10-13T13:00');await page.getByRole('button',{name:'Record',exact:true}).click();
  await expect(page.getByRole('dialog').locator('tbody .badge.delivered')).toHaveCount(2);await page.getByRole('button',{name:'Close dialog'}).click();
  await page.getByRole('button',{name:'LSFAM11A1RA000001',exact:true}).click();
  await expect(page.getByLabel('Comments & port comments')).toHaveValue('Keys checked\nAt port');await expect(page.getByLabel('Price (EUR)',{exact:true})).toHaveValue('95.50');
  await expect(page.getByLabel('T1 customs document')).toHaveValue('yes');await expect(page.getByLabel('ATA · Actual arrival')).toHaveValue('2026-10-13T13:00');
  await page.getByLabel('Comments & port comments').fill('Delivery signed');await page.getByRole('button',{name:'Save changes'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.reload();await page.getByRole('button',{name:/^Unit register/}).click();await expect(page.locator('tbody .badge.delivered')).toHaveCount(2);
  const downloadPromise=page.waitForEvent('download');await page.getByRole('link',{name:'Export CSV'}).click();const download=await downloadPromise;expect(download.suggestedFilename()).toBe('units.csv');
  expect(browserErrors).toEqual([]);
});
test('Import preview prevents invalid VINs and an existing VIN updates without duplication',async({page})=>{
  await page.getByRole('button',{name:'Import units',exact:true}).click();await page.getByLabel('Packing list name *').fill('VIN paste');
  await page.getByLabel('Paste sheet data').fill('LSFAM11A1RA000001\nBAD');await page.getByRole('button',{name:'Review data'}).click();
  await expect(page.getByRole('button',{name:'Import 2 units'})).toBeDisabled();await expect(page.getByRole('alert')).toContainText('Fix 1 row');
  await page.getByRole('button',{name:'Back to paste'}).click();await page.getByLabel('Paste sheet data').fill('LSFAM11A1RA000001');await page.getByRole('button',{name:'Review data'}).click();await page.getByRole('button',{name:'Import 1 units'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button',{name:'Import units',exact:true}).click();await page.getByLabel('Packing list name *').fill('VIN paste');await page.getByLabel('Paste sheet data').fill('VIN\tModel\nLSFAM11A1RA000001\tDeliver 9');await page.getByRole('button',{name:'Review data'}).click();await expect(page.getByText('Update',{exact:true})).toBeVisible();await page.getByRole('button',{name:'Import 1 units'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button',{name:/^Unit register/}).click();await expect(page.locator('tbody tr')).toHaveCount(1);await expect(page.getByText('Deliver 9',{exact:true})).toBeVisible();
});
test('New projects remain separate and mobile navigation/import work without page overflow',async({page})=>{
  await page.setViewportSize({width:390,height:844});await page.getByRole('button',{name:'Open navigation'}).click();await page.getByRole('button',{name:'New project',exact:true}).click();
  await page.getByLabel('Project name *',{exact:true}).fill('Next shunting project');await page.getByLabel('Customer / brand').fill('Fleet B');await page.getByLabel('Expected units *').fill('120');await page.getByRole('button',{name:'Create project',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  // Close the mobile navigation after creating the project if it remains open.
  const backdrop=page.getByRole('button',{name:'Close navigation'});if(await backdrop.isVisible())await backdrop.click();
  await expect(page.getByRole('heading',{name:'Next shunting project'})).toBeVisible();await expect(page.getByText('120 expected vehicles')).toBeVisible();
  await page.getByRole('button',{name:'Import units',exact:true}).click();await page.getByLabel('Packing list name *').fill('Mobile paste');await page.getByLabel('Paste sheet data').fill('LSFAM11A1RA000010');await page.getByRole('button',{name:'Review data'}).click();await page.getByRole('button',{name:'Import 1 units'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBe(true);
  await page.screenshot({path:'.local/screenshots/mobile.png',fullPage:true});
});
test('Sample project has working load cards and clearly marked demonstration data',async({page})=>{
  await page.getByRole('button',{name:'Explore a sample project'}).click();await expect(page.getByText('Sample project · All vehicles',{exact:false})).toBeVisible();
  await expect(page.getByRole('heading',{name:'Demo · Maxus transport'})).toBeVisible();await expect(page.locator('.load-card')).toHaveCount(3);
  await expect(page.locator('.metric-value').first()).toContainText('24');
  await page.screenshot({path:'.local/screenshots/desktop.png',fullPage:true});
  await page.getByRole('button',{name:'Import units',exact:true}).click();await page.getByLabel('Packing list name *').fill('Test paste');await page.getByLabel('Paste sheet data').fill('LSFAM11A1RA000099');await page.getByRole('button',{name:'Review data'}).click();await page.screenshot({path:'.local/screenshots/import.png',fullPage:true});
});
test('The customer’s raw table fills Loading / Unloading addresses and city/postcode automatically',async({page})=>{
  await page.getByRole('button',{name:'Import units',exact:true}).click();await page.getByLabel('Packing list name *').fill('Generic packing list');
  await page.getByLabel('Paste sheet data').fill('| VIN No | Model | Loading | Unloading |\n| --- | --- | --- | --- |\n| LB3P11SD4TH395104 | P145 | Pantank Haven 1223, Hazopweg 163, 9130 Kallo | Canada quay 527, CLdN Ports Zeebrugge NV, Barlenhuisstraat 2, 8380 Zeebrugge |');
  await expect(page.getByText('4 columns recognised',{exact:true})).toBeVisible();await page.getByRole('button',{name:'Review data'}).click();
  await expect(page.locator('.preview-table')).toContainText('Kallo');await expect(page.locator('.preview-table')).toContainText('Zeebrugge');await page.getByRole('button',{name:'Import 1 units'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button',{name:/^Unit register/}).click();await page.getByRole('button',{name:'LB3P11SD4TH395104',exact:true}).click();
  const pol=page.getByRole('dialog').locator('.form-grid').nth(1),pod=page.getByRole('dialog').locator('.form-grid').nth(2);
  await expect(pol.getByLabel('City',{exact:true})).toHaveValue('Kallo');await expect(pol.getByLabel('Postcode',{exact:true})).toHaveValue('9130');await expect(pol.getByLabel('Address',{exact:true})).toHaveValue('Pantank Haven 1223, Hazopweg 163, 9130 Kallo');
  await expect(pod.getByLabel('City',{exact:true})).toHaveValue('Zeebrugge');await expect(pod.getByLabel('Postcode',{exact:true})).toHaveValue('8380');
});
test('Shared import details fill a VIN-only list and retain supplied cells',async({page})=>{
  await page.getByRole('button',{name:'Import units',exact:true}).click();await page.getByLabel('Packing list name *').fill('Shared route');
  await page.getByLabel('Paste sheet data').fill('VIN No\tPOL-CITY\nLSFAM11A1RA000001\tAntwerp\nLSFAM11A1RA000002\t');
  await page.getByText('Shared POL / POD details · fill missing cells for the whole list',{exact:true}).click();
  await page.getByLabel('POL city',{exact:true}).fill('Kallo');await page.getByLabel('POD address',{exact:true}).fill('Port road, 8380 Zeebrugge');
  await page.getByRole('button',{name:'Review data'}).click();await page.getByRole('button',{name:'Import 2 units'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  const p=await page.getByLabel('Active project').inputValue();const w=await (await page.request.get(`/api/projects/${p}/workspace`)).json();
  expect(w.units.find(u=>u.vin.endsWith('000001')).origin).toBe('Antwerp');expect(w.units.find(u=>u.vin.endsWith('000002')).origin).toBe('Kallo');expect(w.units.every(u=>u.destination==='Zeebrugge')).toBe(true);
});
test('A custom header mapping is remembered for the next packing list',async({page})=>{
  for(const [i,vin] of ['LSFAM11A1RA000001','LSFAM11A1RA000002'].entries()){
    await page.getByRole('button',{name:'Import units',exact:true}).click();await page.getByLabel('Packing list name *').fill(`Custom ${i}`);await page.getByLabel('Paste sheet data').fill(`VIN No\tArrival yard\n${vin}\tPort road, 8380 Zeebrugge`);await page.getByRole('button',{name:'Review data'}).click();
    if(i===0)await page.getByLabel('Arrival yard',{exact:true}).selectOption('pod_address');
    else await expect(page.getByLabel('Arrival yard',{exact:true})).toHaveValue('pod_address');
    await page.getByRole('button',{name:'Import 1 units'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  }
  const p=await page.getByLabel('Active project').inputValue();const w=await (await page.request.get(`/api/projects/${p}/workspace`)).json();expect(w.units.length).toBe(2);expect(w.units.every(u=>u.destination==='Zeebrugge')).toBe(true);
});
test('Bulk editing all matching vehicles spans pages and preserves fields not selected',async({page})=>{
  const p=await page.getByLabel('Active project').inputValue();
  await page.request.post(`/api/projects/${p}/import`,{data:{packingList:'Bulk list',rows:Array.from({length:51},(_,i)=>({vin:`LSFAM11A1RA${String(i+1).padStart(6,'0')}`,origin:i===0?'Existing origin':'',notes:'Keep notes'}))}});
  await page.getByRole('button',{name:'Refresh workspace'}).click();await page.getByRole('button',{name:/^Unit register/}).click();await page.getByLabel('Rows per page').selectOption('50');await page.getByRole('checkbox',{name:'Select this page'}).check();await page.getByRole('button',{name:'Select all 51 matching vehicles'}).click();await page.getByRole('button',{name:'Bulk edit',exact:true}).click();
  await expect(page.getByRole('heading',{name:'Bulk edit 51 vehicles'})).toBeVisible();await page.getByLabel('Action 1').selectOption('fill');await page.getByLabel('Value 1').fill('Kallo');
  await page.getByRole('button',{name:'Add another field'}).click();await page.getByLabel('Field 2',{exact:true}).selectOption('destination');await page.getByLabel('Value 2',{exact:true}).fill('Zeebrugge');
  await expect(page.getByRole('button',{name:'Apply to 51 vehicles'})).toBeEnabled();await page.screenshot({path:'.local/screenshots/bulk-edit.png',fullPage:true});await page.getByRole('button',{name:'Apply to 51 vehicles'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  const w=await (await page.request.get(`/api/projects/${p}/workspace`)).json();expect(w.units[0].origin).toBe('Existing origin');expect(w.units[50].origin).toBe('Kallo');expect(w.units.every(u=>u.destination==='Zeebrugge'&&u.notes==='Keep notes')).toBe(true);
});

test('400 VINs show on one page and batches of 200 assign to separate carrier workspaces in packing-list order',async({page})=>{
  const browserErrors=[];page.on('pageerror',e=>browserErrors.push(e.message));
  const p=await page.getByLabel('Active project').inputValue();
  const rows=Array.from({length:400},(_,i)=>({vin:`LSFAM11A1RA${String(400-i).padStart(6,'0')}`,origin:'Kallo',destination:'Zeebrugge'}));
  await page.request.post(`/api/projects/${p}/import`,{data:{packingList:'Original packing order',rows}});
  await page.getByRole('button',{name:'Refresh workspace'}).click();await page.getByRole('button',{name:/^Unit register/}).click();
  await expect(page.locator('tbody tr')).toHaveCount(200);await page.getByLabel('Rows per page').selectOption('all');await expect(page.locator('tbody tr')).toHaveCount(400);
  await expect(page.locator('tbody .vin-link').first()).toHaveText(rows[0].vin);await expect(page.locator('tbody .vin-link').last()).toHaveText(rows[399].vin);
  await page.getByLabel('Number of VINs to select').fill('200');await page.getByRole('button',{name:'Select 200 VINs',exact:true}).click();
  await expect(page.locator('.row-selected')).toHaveCount(200);await page.getByRole('button',{name:'Assign to carrier',exact:true}).click();
  await expect(page.getByRole('dialog')).toContainText(rows[0].vin);await expect(page.getByRole('dialog')).toContainText(rows[199].vin);
  await page.getByLabel('Carrier name *',{exact:true}).fill('Carrier A');await page.getByRole('button',{name:'Assign 200 vehicles',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button',{name:'Select 200 VINs',exact:true}).click();await expect(page.locator('.row-selected .vin-link').first()).toHaveText(rows[200].vin);
  await page.getByRole('button',{name:'Assign to carrier',exact:true}).click();await page.getByLabel('Assign carrier *',{exact:true}).selectOption('new');await page.getByLabel('Carrier name *',{exact:true}).fill('Carrier B');await page.getByRole('button',{name:'Assign 200 vehicles',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button',{name:/^Carriers/}).click();await expect(page.getByRole('heading',{name:'Carrier operations'})).toBeVisible();
  await page.getByRole('button',{name:'Open Carrier A',exact:true}).click();await expect(page.locator('.carrier-unit-table tbody tr')).toHaveCount(200);
  await expect(page.locator('.carrier-unit-table tbody .vin-link').first()).toHaveText(rows[0].vin);await expect(page.getByRole('button',{name:'Paste sheet update'})).toBeEnabled();
  await page.screenshot({path:'.local/screenshots/carrier-workspace.png',fullPage:false});
  await page.getByLabel('Carrier workspace').selectOption({label:'Carrier B'});await expect(page.locator('.carrier-unit-table tbody .vin-link').first()).toHaveText(rows[200].vin);
  await page.getByRole('button',{name:'Open register for selection / bulk edit'}).click();await expect(page.locator('tbody tr')).toHaveCount(200);
  await expect(page.getByLabel('Filter carrier')).not.toHaveValue('all');expect(browserErrors).toEqual([]);
});

test('Carrier sheet gaps preview load builds; later milestone pastes reuse VINs and update progress',async({page})=>{
  const p=await page.getByLabel('Active project').inputValue(),vins=[1,2,3,4].map(i=>`LSFAM11A1RA${String(i).padStart(6,'0')}`);
  await page.request.post(`/api/projects/${p}/import`,{data:{packingList:'Daily carrier test',rows:vins.map(vin=>({vin,notes:'Original note'}))}});
  await page.getByRole('button',{name:'Refresh workspace'}).click();await page.getByRole('button',{name:/^Unit register/}).click();await page.getByLabel('Number of VINs to select').fill('4');await page.getByRole('button',{name:'Select 4 VINs',exact:true}).click();await page.getByRole('button',{name:'Assign to carrier',exact:true}).click();await page.getByLabel('Carrier name *').fill('Daily Carrier');await page.getByRole('button',{name:'Assign 4 vehicles',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button',{name:/^Carriers/}).click();await page.getByRole('button',{name:'Open Daily Carrier',exact:true}).click();
  const sheet=(actual=false)=>'VIN No\tETD\tETA\tATD\tATA\tComments\n'+vins.map((vin,i)=>(i===2?'\n':'')+`${vin}\t${actual?'':'12/10/2026 08:00'}\t13/10/2026 12:00\t${actual?'12/10/2026 09:00':''}\t${actual?'13/10/2026 13:00':''}\t`).join('\n');
  async function paste(actual=false){await page.getByRole('button',{name:'Paste sheet update'}).click();await page.getByLabel('Paste carrier sheet').fill(sheet(actual));await page.getByRole('button',{name:'Review changes'}).click();await expect(page.getByText('New load builds',{exact:true})).toBeVisible();}
  await paste();await expect(page.locator('.proposed-load')).toHaveCount(2);await expect(page.getByRole('dialog').locator('.review-summary')).toContainText('2New load builds');await expect(page.getByRole('dialog').locator('.changes-table .badge.scheduled')).toHaveCount(4);
  await page.screenshot({path:'.local/screenshots/carrier-update-review.png',fullPage:true});await page.getByRole('button',{name:'Apply update · 4 changed',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.locator('.carrier-unit-table .badge.scheduled')).toHaveCount(4);
  await paste(true);await expect(page.getByRole('dialog').locator('.review-summary')).toContainText('0New load builds');await expect(page.getByRole('dialog').locator('.changes-table .badge.delivered')).toHaveCount(4);await page.getByRole('button',{name:'Apply update · 4 changed',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.locator('.carrier-unit-table .badge.delivered')).toHaveCount(4);
  await paste(true);await page.getByRole('button',{name:'Apply update · 0 changed',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.locator('.carrier-history tbody tr')).toHaveCount(3);
  const w=await (await page.request.get(`/api/projects/${p}/workspace`)).json();expect(w.units.length).toBe(4);expect(w.loads.length).toBe(2);expect(w.units.every(u=>u.notes==='Original note'&&u.etd&&u.atd&&u.ata&&u.packing_list==='Daily carrier test')).toBe(true);
});

test('Carrier paste blocks unassigned VINs and a new carrier can be added without selecting vehicles',async({page})=>{
  const p=await page.getByLabel('Active project').inputValue();await page.request.post(`/api/projects/${p}/import`,{data:{packingList:'Known VIN',rows:[{vin:'LSFAM11A1RA000001',carrier:'Known Carrier'}]}});
  await page.getByRole('button',{name:'Refresh workspace'}).click();await page.getByRole('button',{name:/^Carriers/}).click();await page.getByRole('button',{name:'New carrier',exact:true}).click();await page.getByLabel('Carrier name *').fill('Second Carrier');await page.getByRole('dialog').getByRole('button',{name:'Add carrier',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button',{name:'Open Known Carrier',exact:true}).click();await page.getByRole('button',{name:'Paste sheet update'}).click();await page.getByLabel('Paste carrier sheet').fill('VIN\tETA\nLSFAM11A1RA000002\t13/10/2026');await expect(page.getByRole('alert')).toContainText('Not in the packing list');await expect(page.getByRole('button',{name:'Review changes'})).toBeDisabled();await page.getByRole('button',{name:'Close dialog'}).click();
  const w=await (await page.request.get(`/api/projects/${p}/workspace`)).json();expect(w.carriers).toHaveLength(2);expect(w.units).toHaveLength(1);
});

test('Load builds chooses a carrier and repeatedly reads a full 200-VIN sheet with twelve loads and an unbuilt remainder',async({page})=>{
  test.setTimeout(60000);
  const p=await page.getByLabel('Active project').inputValue(),vins=Array.from({length:200},(_,i)=>`LSFAM11A1RA${String(i+1).padStart(6,'0')}`);
  await page.request.post(`/api/projects/${p}/import`,{data:{packingList:'Full source batch',rows:vins.map(vin=>({vin,carrier:'Valida',notes:'Keep original note'}))}});
  await page.getByRole('button',{name:'Refresh workspace'}).click();await page.getByRole('button',{name:/^Load builds/}).click();
  await page.getByRole('button',{name:/^Valida/}).click();await expect(page.getByRole('button',{name:'Paste full batch for Valida'})).toBeEnabled();
  const header='Brand\tVIN\tModel\tAppointment #\tComments\tPOL-COUNTRY\tPOL-CITY\tPOL-ADDRESS\tPOD-COUNTRY\tPOD-CITY\tPOD-ADDRESS\tETD\tATD\tETA\tATA\tTruck plate\t\t';
  const sheet=(built=72,actual=false)=>header+'\n'+vins.map((vin,i)=>(i>0&&i<built&&i%6===0?'\t\t\n':'')+['Geely',vin,'P145','','','Belgium','Antwerp','Port street','Belgium','Zeebrugge','Quay street',i<built?'2026/10/07':'',actual&&i<6?'2026/10/07 09:00':'',i<built?'2026/10/07 12:00':'',actual&&i<6?'2026/10/07 11:00':'',i<built?'TEST-01':'','',''].join('\t')).join('\n')+'\n'+'\t\t\n'.repeat(800);
  await page.getByRole('button',{name:'Paste full batch for Valida'}).click();await page.getByLabel('Paste carrier sheet').fill(sheet());
  await expect(page.getByRole('dialog').locator('.review-summary')).toContainText('12Detected loads');await expect(page.getByRole('dialog').locator('.review-summary')).toContainText('128Not load built');
  await expect(page.getByRole('dialog').locator('.sheet-table tbody tr')).toHaveCount(200);await expect(page.getByRole('dialog').getByLabel('Appointment #',{exact:true})).toHaveValue('reference');
  await page.getByRole('button',{name:'Review changes'}).click();await expect(page.locator('.proposed-load')).toHaveCount(12);await expect(page.getByRole('dialog').locator('.changes-table tbody tr')).toHaveCount(200);await expect(page.getByRole('dialog').locator('.review-summary')).toContainText('128Not load built');
  await page.screenshot({path:'.local/screenshots/full-batch-review.png',fullPage:false});await page.getByRole('button',{name:'Apply update · 200 changed',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('.all-loads .load-card')).toHaveCount(12);await expect(page.locator('.load-full-batch tbody tr')).toHaveCount(200);await expect(page.locator('.load-full-batch .sheet-tag.pool')).toHaveCount(128);
  await page.screenshot({path:'.local/screenshots/load-build-carriers.png',fullPage:false});
  await page.getByRole('button',{name:'Paste carrier sheet',exact:true}).click();await page.getByLabel('Paste carrier sheet').fill(sheet());await page.getByRole('button',{name:'Review changes'}).click();await expect(page.getByRole('button',{name:'Apply update · 0 changed',exact:true})).toBeEnabled();await page.getByRole('button',{name:'Apply update · 0 changed',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button',{name:'Paste full batch for Valida'}).click();await page.getByLabel('Paste carrier sheet').fill(sheet(78,true));await page.getByRole('button',{name:'Review changes'}).click();await expect(page.getByRole('dialog').locator('.review-summary')).toContainText('1New load builds');await expect(page.getByRole('dialog').locator('.review-summary')).toContainText('122Not load built');await page.getByRole('button',{name:'Apply update · 12 changed',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  const w=await (await page.request.get(`/api/projects/${p}/workspace`)).json();expect(w.units).toHaveLength(200);expect(w.loads).toHaveLength(13);expect(w.units.filter(u=>!u.load_id)).toHaveLength(122);expect(w.units.filter(u=>u.status==='delivered')).toHaveLength(6);expect(w.units.every(u=>u.notes==='Keep original note'&&u.packing_list==='Full source batch')).toBe(true);
  await page.setViewportSize({width:390,height:844});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBe(true);
});

test('Project load pricing, unit revenue and ready load totals are usable from the dashboard',async({page,request})=>{
  const p=await page.getByLabel('Active project').inputValue(),base=`/api/projects/${p}`;
  await request.post(base+'/import',{data:{packingList:'Finance batch',rows:[1,2].map(i=>({vin:`LSFAM11A1RA${String(i).padStart(6,'0')}`,reference:'Booking test',price:'90'}))}});
  let w=await (await request.get(base+'/workspace')).json();const l=await (await request.post(base+'/loads',{data:{reference:'FIN-001',carrier:'Finance carrier'}})).json();
  await request.post(base+`/loads/${l.id}/assign`,{data:{unitIds:w.units.map(u=>u.id)}});await page.reload();
  await expect(page.locator('.load-summary')).toContainText('Scheduled loads');await expect(page.locator('.load-summary .load-metrics>div').nth(1)).toContainText('1');await expect(page.locator('.load-summary .load-metrics>div').nth(2)).toContainText('1');
  await page.getByRole('button',{name:'Pricing & analysis'}).click();await page.getByLabel('Cost basis',{exact:true}).selectOption('load');
  await page.getByLabel('Load cost default (EUR)',{exact:true}).fill('500');await page.getByLabel('Unit revenue default (EUR)',{exact:true}).fill('300');
  await page.getByRole('button',{name:'Save project rates'}).click();await expect(page.locator('.finance-summary')).toContainText('€500.00');await expect(page.locator('.finance-summary')).toContainText('€600.00');await expect(page.locator('.finance-summary')).toContainText('€100.00');
  await page.getByRole('checkbox',{name:'Select price FIN-001'}).check();await page.getByLabel('Bulk load cost (EUR)').fill('550');await page.getByLabel('Bulk load price action').selectOption('replace');await page.getByRole('button',{name:'Apply to 1 loads'}).click();await expect(page.locator('.finance-summary')).toContainText('€50.00');
  await page.getByRole('button',{name:'FIN-001',exact:true}).click();await expect(page.getByLabel('Load cost (EUR)',{exact:true})).toHaveValue('550');await page.getByLabel('Load revenue (EUR)',{exact:true}).fill('700');await page.getByRole('button',{name:'Save load changes'}).click();
  w=await (await request.get(base+'/workspace')).json();expect(w.units.map(u=>u.price)).toEqual(['90','90']);expect(w.units.map(u=>u.revenue)).toEqual(['300','300']);expect(w.loads[0].revenue).toBe('700');
  await page.screenshot({path:'.local/screenshots/pricing.png',fullPage:true});
});

test('Calendar groups load VINs by local date, supports delivery dates and carrier filtering, and opens details',async({page,request})=>{
  const p=await page.getByLabel('Active project').inputValue(),base=`/api/projects/${p}`;
  await request.post(base+'/import',{data:{packingList:'Calendar batch',rows:[1,2,3].map(i=>({vin:`LSFAM11A1RA${String(i).padStart(6,'0')}`}))}});
  const w=await (await request.get(base+'/workspace')).json();const l=await (await request.post(base+'/loads',{data:{reference:'CAL-001',carrier:'Calendar carrier',etd:'2026-10-11T23:30:00Z',eta:'2026-10-13T08:00:00Z'}})).json();
  await request.post(base+`/loads/${l.id}/assign`,{data:{unitIds:w.units.slice(0,2).map(u=>u.id)}});await request.patch(base+`/units/${w.units[2].id}`,{data:{carrier:'Other calendar carrier',etd:'2026-10-12T09:00:00Z'}});await page.reload();
  await page.getByRole('button',{name:'Calendar',exact:true}).click();await page.getByLabel('Calendar month').fill('2026-10');
  const day=page.locator('[data-date="2026-10-12"]');await expect(day.locator('.calendar-event')).toHaveCount(2);await expect(day).toContainText('Pickup 01:30');await expect(day).toContainText('2 VINs');
  await page.getByLabel('Calendar dates').selectOption('delivery');await expect(page.locator('[data-date="2026-10-13"]')).toContainText('Delivery 10:00');await expect(page.locator('.calendar-event')).toHaveCount(1);
  await page.getByLabel('Calendar dates').selectOption('both');await page.getByLabel('Calendar carrier').selectOption('Calendar carrier');await expect(page.locator('.calendar-event')).toHaveCount(2);
  await page.getByRole('button',{name:'Next month'}).click();await expect(page.getByRole('heading',{name:'November 2026'})).toBeVisible();await page.getByRole('button',{name:'Previous month'}).click();
  await page.screenshot({path:'.local/screenshots/calendar.png',fullPage:true});await day.getByRole('button',{name:/CAL-001/}).click();await expect(page.getByRole('dialog')).toContainText('CAL-001');
});

test('A carrier paste prominently warns about changed dates and saves follow-up alerts with affected VINs',async({page,request})=>{
  const p=await page.getByLabel('Active project').inputValue(),base=`/api/projects/${p}`;
  await request.post(base+'/import',{data:{packingList:'Risk batch',rows:[1,2].map(i=>({vin:`LSFAM11A1RA${String(i).padStart(6,'0')}`}))}});
  let w=await (await request.get(base+'/workspace')).json();const l=await (await request.post(base+'/loads',{data:{reference:'RISK-001',carrier:'Risk carrier',etd:'2026-10-12T08:00:00Z',eta:'2026-10-13T08:00:00Z'}})).json();
  await request.post(base+`/loads/${l.id}/assign`,{data:{unitIds:w.units.map(u=>u.id)}});await page.reload();await page.getByRole('button',{name:/^Load builds/}).click();await page.getByRole('button',{name:'Paste full batch for Risk carrier'}).click();
  await page.getByLabel('Paste carrier sheet').fill('VIN\tLoad\tAppointment #\tETD\tETA\nLSFAM11A1RA000001\tRISK-001\tBOOKING-1\t14/10/2026 10:00\t15/10/2026 10:00\nLSFAM11A1RA000002\tRISK-001\tBOOKING-2\t14/10/2026 10:00\t15/10/2026 10:00');
  await page.getByRole('button',{name:'Review changes'}).click();await expect(page.locator('.schedule-warning')).toContainText('2 affected VINs');await expect(page.locator('.schedule-warning')).toContainText('RISK-001');await expect(page.locator('.schedule-warning')).toContainText('Pickup later');await expect(page.locator('.schedule-warning')).toContainText('Delivery later');
  await page.locator('.schedule-warning details').first().locator('summary').click();await expect(page.locator('.schedule-warning')).toContainText('LSFAM11A1RA000001');await page.screenshot({path:'.local/screenshots/schedule-warning.png',fullPage:true});
  await page.getByRole('button',{name:'Apply update · 2 changed'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await page.getByRole('button',{name:'Overview',exact:true}).click();await expect(page.locator('.saved-alerts')).toContainText('RISK-001');
  await page.getByRole('button',{name:'Schedule changes',exact:true}).click();await page.locator('.saved-alerts details').first().locator('summary').click();await expect(page.locator('.saved-alerts .risk-vins').first()).toContainText('LSFAM11A1RA000001');
  await page.getByRole('button',{name:'Mark followed up'}).first().click();await expect(page.getByRole('button',{name:'Mark followed up'})).toHaveCount(1);await page.getByRole('button',{name:'Mark followed up'}).click();await expect(page.getByText('No outstanding schedule changes.')).toBeVisible();
  await page.getByLabel('Show followed-up changes').check();await expect(page.locator('.saved-alerts')).toContainText('Followed up');w=await (await request.get(base+'/workspace')).json();expect(w.units.every(u=>u.status==='ready')).toBe(true);expect(w.scheduleAlerts.every(a=>a.resolved_at)).toBe(true);
});

test('Project settings rename the project and switch progress from an editable estimate to packing-list totals',async({page,request})=>{
  const p=await page.getByLabel('Active project').inputValue(),base=`/api/projects/${p}`;
  await request.post(base+'/import',{data:{packingList:'Final manifest',rows:[1,2,3].map(i=>({vin:`LSFAM11A1RA${String(i).padStart(6,'0')}`,notes:'Keep notes',ata:i===1?'2026-10-12T08:00:00Z':''}))}});await page.reload();
  await page.getByRole('button',{name:'Project settings',exact:true}).click();await page.getByLabel('Project name *',{exact:true}).fill('Renamed transport project');await page.getByLabel('Customer / brand').fill('Flexible brand');await page.getByLabel('Estimated units *').fill('350');await page.getByRole('button',{name:'Save project settings'}).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.locator('.project-banner')).toContainText('350 expected vehicles');await expect(page.getByLabel('Active project')).toContainText('Renamed transport project');
  await page.getByRole('button',{name:'Project settings',exact:true}).click();await page.getByLabel('Project volume',{exact:true}).selectOption('packing_list');await page.screenshot({path:'.local/screenshots/project-settings.png',fullPage:true});await page.getByRole('button',{name:'Save project settings'}).click();
  await expect(page.locator('.project-banner')).toContainText('3 vehicles · packing-list total');await expect(page.locator('.project-progress strong')).toContainText('33');
  await request.post(base+'/import',{data:{packingList:'Extra volume',rows:[{vin:'LSFAM11A1RA000004'}]}});await page.getByRole('button',{name:'Refresh workspace'}).click();await expect(page.locator('.project-banner')).toContainText('4 vehicles · packing-list total');await expect(page.locator('.project-progress strong')).toContainText('25');
  await page.reload();await expect(page.locator('.project-banner')).toContainText('Renamed transport project');await expect(page.locator('.project-banner')).toContainText('4 vehicles · packing-list total');
  await page.getByRole('button',{name:'Project settings',exact:true}).click();await expect(page.getByLabel('Estimated units *')).toHaveValue('350');await page.getByLabel('Project volume',{exact:true}).selectOption('estimate');await page.getByRole('button',{name:'Save project settings'}).click();await expect(page.locator('.project-banner')).toContainText('350 expected vehicles');
  const w=await (await request.get(base+'/workspace')).json();expect(w.units).toHaveLength(4);expect(w.units[0].notes).toBe('Keep notes');expect(w.units[0].ata).toBe('2026-10-12T08:00:00Z');
});

test('Confirmed project deletion switches to another project and supports deleting the last one then starting again',async({page,request})=>{
  const p=await page.getByLabel('Active project').inputValue();await request.patch(`/api/projects/${p}`,{data:{name:'Delete test project'}});
  await request.post(`/api/projects/${p}/import`,{data:{packingList:'Delete manifest',rows:[{vin:'LSFAM11A1RA000001'}]}});await page.reload();
  await page.getByRole('button',{name:'Project settings',exact:true}).click();await page.getByRole('button',{name:'Delete project',exact:true}).click();
  await expect(page.getByRole('button',{name:'Permanently delete project'})).toBeDisabled();await page.getByLabel('Type the project name to delete').fill('Wrong name');await expect(page.getByRole('button',{name:'Permanently delete project'})).toBeDisabled();await page.getByRole('button',{name:'Keep project'}).click();await page.getByRole('button',{name:'Cancel',exact:true}).click();
  await expect(page.getByLabel('Active project')).toHaveValue(p);
  await page.getByRole('button',{name:'Project settings',exact:true}).click();await page.getByRole('button',{name:'Delete project',exact:true}).click();await page.getByLabel('Type the project name to delete').fill('Delete test project');await page.getByRole('button',{name:'Permanently delete project'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.getByLabel('Active project')).not.toHaveValue(p);expect((await request.get(`/api/projects/${p}/workspace`)).status()).toBe(404);
  // Isolate the remaining empty-workspace case without affecting other tests' setup records.
  const others=await (await request.get('/api/projects')).json();for(const other of others){expect((await request.delete(`/api/projects/${other.id}`,{data:{confirmName:other.name}})).status()).toBe(200);}
  await page.reload();await expect(page.getByRole('heading',{name:'No projects yet'})).toBeVisible();await expect(page.getByRole('button',{name:'Project settings',exact:true})).toBeDisabled();
  await page.getByRole('button',{name:'Create your first project'}).click();await page.getByLabel('Project name *',{exact:true}).fill('Fresh project');await page.getByRole('button',{name:'Create project',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.locator('.project-banner')).toContainText('Fresh project');
  await page.getByRole('button',{name:'Project settings',exact:true}).click();await page.getByRole('button',{name:'Delete project',exact:true}).click();await page.getByLabel('Type the project name to delete').fill('Fresh project');await page.getByRole('button',{name:'Permanently delete project'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.getByRole('heading',{name:'No projects yet'})).toBeVisible();await page.reload();await expect(page.getByRole('heading',{name:'No projects yet'})).toBeVisible();
});


test('Carrier exports copy VINs and details for the allocated batch, support column choices and filtered rows, and download CSV',async({page,request,context})=>{
  await context.grantPermissions(['clipboard-read','clipboard-write']);
  const p=await page.getByLabel('Active project').inputValue(),base=`/api/projects/${p}`;
  const rows=Array.from({length:400},(_,i)=>({vin:`LSFAM11A1RA${String(i+1).padStart(6,'0')}`,model:'P145',brand:'MAXUS',carrier:i<200?'Export carrier A':'Export carrier B',origin:'Kallo',pol_address:'Port road',destination:'Zeebrugge',notes:'Keys checked\nSecond comment',price:'95.50',revenue:'125.75'}));
  await request.post(base+'/import',{data:{packingList:'Export allocation',rows}});const before=await (await request.get(base+'/workspace')).json();await page.reload();await page.getByRole('button',{name:/^Carriers/}).click();await page.getByLabel('Carrier workspace').selectOption(before.carriers.find(c=>c.name==='Export carrier A').id);
  await page.getByRole('button',{name:'Export carrier details',exact:true}).click();await expect(page.locator('.export-preview tbody tr')).toHaveCount(200);await page.getByRole('button',{name:'Copy table',exact:true}).click();await expect(page.getByRole('status')).toContainText('200 VIN rows copied');
  let copied=await page.evaluate(()=>navigator.clipboard.readText()),grid=parseGrid(copied);expect(grid).toHaveLength(201);expect(grid[1][grid[0].indexOf('VIN')]).toBe('LSFAM11A1RA000001');expect(grid[200][grid[0].indexOf('VIN')]).toBe('LSFAM11A1RA000200');expect(grid[1][grid[0].indexOf('Model')]).toBe('P145');expect(grid[1][grid[0].indexOf('Comments')]).toBe('Keys checked\nSecond comment');expect(copied).not.toContain('Export carrier B');expect(grid[0]).not.toContain('Price(EUR)');
  const html=await page.evaluate(async()=>{const items=await navigator.clipboard.read();return (await items[0].getType('text/html')).text();});expect(html).toContain('<table');expect(html).toContain('P145');
  await page.getByText('Choose export columns',{exact:false}).click();await page.getByRole('checkbox',{name:'Price(EUR)',exact:true}).check();await page.getByRole('checkbox',{name:'Unit revenue (EUR)',exact:true}).check();
  await page.getByText('Column order · match your existing sheet',{exact:true}).click();await page.getByRole('button',{name:'Move Brand left',exact:true}).click();await page.getByRole('button',{name:'Copy table',exact:true}).click();await expect(page.getByRole('status')).toContainText('200 VIN rows copied');const reordered=parseGrid(await page.evaluate(()=>navigator.clipboard.readText()));expect(reordered[0].slice(0,2)).toEqual(['Brand','VIN']);expect(reordered[1][0]).toBe('MAXUS');
  const downloadPromise=page.waitForEvent('download');await page.getByRole('button',{name:'Download CSV',exact:true}).click();const download=await downloadPromise;expect(download.suggestedFilename()).toBe('carrier-Export-carrier-A.csv');const csv=readFileSync(await download.path(),'utf8');expect(csv).toContain('95.50');expect(csv).toContain('125.75');expect(csv).not.toContain('Export carrier B');
  await page.getByRole('button',{name:'Close dialog',exact:true}).click();await page.getByLabel('Search carrier vehicles').fill('LSFAM11A1RA000005');await page.getByRole('button',{name:'Export carrier details',exact:true}).click();await page.getByLabel('Vehicles to export').selectOption('filtered');await expect(page.locator('.export-preview tbody tr')).toHaveCount(1);await page.getByRole('button',{name:'Copy table',exact:true}).click();await expect(page.getByRole('status')).toContainText('1 VIN rows copied');copied=await page.evaluate(()=>navigator.clipboard.readText());expect(parseGrid(copied)[1][0]).toBe('LSFAM11A1RA000005');
  expect(await (await request.get(base+'/workspace')).json()).toEqual(before);
});

test('Detected loads export announcement tables with per-VIN truck and ETD, gaps between loads, and missing-detail warnings',async({page,request,context})=>{
  await context.grantPermissions(['clipboard-read','clipboard-write']);const p=await page.getByLabel('Active project').inputValue(),base=`/api/projects/${p}`;
  await request.post(base+'/import',{data:{packingList:'Announcement batch',rows:[1,2,3,4].map(i=>({vin:`LSFAM11A1RA${String(i).padStart(6,'0')}`,model:'P145',carrier:'Announcement carrier'}))}});
  let w=await (await request.get(base+'/workspace')).json();const path=base+`/carriers/${w.carriers[0].id}/updates`,body={groupLoads:true,rows:[{vin:w.units[0].vin,load_reference:'ANN-001',truck:'TEST-A',etd:'2026-10-12T08:00:00Z'},{vin:w.units[1].vin,load_reference:'ANN-001',truck:'TEST-B',etd:'2026-10-12T09:00:00Z'},{vin:w.units[2].vin,load_reference:'ANN-002'},{vin:w.units[3].vin,load_action:'pool'}]};
  const review=await (await request.post(path+'/preview',{data:body})).json();expect((await request.post(path,{data:{...body,snapshot:review.snapshot}})).status()).toBe(200);w=await (await request.get(base+'/workspace')).json();await page.reload();await page.getByRole('button',{name:/^Load builds/}).click();await page.getByRole('button',{name:'Export announcement for ANN-001',exact:true}).click();
  await expect(page.locator('.export-preview tbody tr')).toHaveCount(2);await page.getByRole('button',{name:'Copy table',exact:true}).click();await expect(page.getByRole('status')).toContainText('2 VIN rows copied');let grid=parseGrid(await page.evaluate(()=>navigator.clipboard.readText()));expect(grid[1][grid[0].indexOf('Truck plate')]).toBe('TEST-A');expect(grid[2][grid[0].indexOf('Truck plate')]).toBe('TEST-B');expect(grid[1][grid[0].indexOf('ETD')]).toBe('2026-10-12');expect(grid[2][grid[0].indexOf('ETD')]).toBe('2026-10-12');
  await expect(page.getByRole('checkbox',{name:'Include hours and minutes',exact:true})).not.toBeChecked();await expect(page.getByRole('checkbox',{name:'ISO dates with timezone',exact:true})).toBeDisabled();
  await page.getByRole('checkbox',{name:'Include hours and minutes',exact:true}).check();await expect(page.locator('.export-preview')).toContainText('2026-10-12 10:00');await page.getByRole('button',{name:'Copy table',exact:true}).click();await expect(page.getByRole('status')).toContainText('2 VIN rows copied');grid=parseGrid(await page.evaluate(()=>navigator.clipboard.readText()));expect(grid[1][grid[0].indexOf('ETD')]).toBe('2026-10-12 10:00');expect(grid[2][grid[0].indexOf('ETD')]).toBe('2026-10-12 11:00');
  await page.getByRole('checkbox',{name:'ISO dates with timezone',exact:true}).check();await expect(page.locator('.export-preview')).toContainText('2026-10-12T08:00:00.000Z');await page.getByRole('checkbox',{name:'Include hours and minutes',exact:true}).uncheck();await expect(page.getByRole('checkbox',{name:'ISO dates with timezone',exact:true})).not.toBeChecked();await expect(page.locator('.export-preview')).not.toContainText('10:00');
  await page.screenshot({path:'.local/screenshots/announcement-export.png',fullPage:true});await page.getByRole('button',{name:'Close dialog',exact:true}).click();await page.getByRole('button',{name:'Export load announcements',exact:true}).click();await expect(page.getByRole('alert')).toContainText('1 VIN missing a truck plate');await page.getByRole('button',{name:'Copy table',exact:true}).click();await expect(page.getByRole('status')).toContainText('3 VIN rows copied');grid=parseGrid(await page.evaluate(()=>navigator.clipboard.readText()),{preserveBlankRows:true});expect(grid).toHaveLength(5);expect(grid[3].every(v=>!v)).toBe(true);expect(grid[4][grid[0].indexOf('Load')]).toBe('ANN-002');expect(grid[1][grid[0].indexOf('ETD')]).toBe('2026-10-12');expect(grid.flat()).not.toContain(w.units[3].vin);
  const downloadPromise=page.waitForEvent('download');await page.getByRole('button',{name:'Download CSV',exact:true}).click();const download=await downloadPromise;expect(download.suggestedFilename()).toContain('announcement-');const announcementCsv=readFileSync(await download.path(),'utf8');expect(announcementCsv).toContain('Truck plate');expect(announcementCsv).toContain('2026-10-12');expect(announcementCsv).not.toContain('10:00');expect(announcementCsv).not.toContain('11:00');await page.getByRole('button',{name:'Close dialog',exact:true}).click();
  await page.getByRole('button',{name:/^ANN-001/}).first().click();await page.getByLabel('Truck plate',{exact:true}).fill('Unsaved plate');await expect(page.getByRole('button',{name:'Export announcement',exact:true})).toBeDisabled();await page.getByLabel('Truck plate',{exact:true}).fill('');await page.getByRole('button',{name:'Export announcement',exact:true}).click();await expect(page.locator('dialog[open]')).toHaveCount(2);await page.locator('dialog[open]').last().getByRole('button',{name:'Close dialog',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(1);
  expect(await (await request.get(base+'/workspace')).json()).toEqual(w);
});

test('Selected unit details export has a manual-copy fallback when clipboard permission is denied',async({page,request})=>{
  const p=await page.getByLabel('Active project').inputValue();await request.post(`/api/projects/${p}/import`,{data:{packingList:'Manual export',rows:[{vin:'LSFAM11A1RA000001',model:'P145'}]}});await page.reload();await page.getByRole('button',{name:/^Unit register/}).click();await page.getByRole('checkbox',{name:'Select this page'}).check();await page.getByRole('button',{name:'Export selected details',exact:true}).click();
  await page.evaluate(()=>{Object.defineProperty(navigator,'clipboard',{configurable:true,value:{write:async()=>{throw new Error('Permission denied');},writeText:async()=>{throw new Error('Permission denied');}}});});await page.getByRole('button',{name:'Copy table',exact:true}).click();await expect(page.getByRole('status')).toContainText('Clipboard access is unavailable');await expect(page.getByLabel('Export spreadsheet text')).toBeVisible();await expect(page.getByLabel('Export spreadsheet text')).toContainText('P145');await page.getByRole('button',{name:'Select export text',exact:true}).click();expect(await page.getByLabel('Export spreadsheet text').evaluate(el=>el.selectionEnd-el.selectionStart)).toBeGreaterThan(20);
});
