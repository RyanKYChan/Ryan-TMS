import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openDb } from '../server/db.js';
import { createApp } from '../server/app.js';
const vin=i=>`LSFAM11A1RA${String(i).padStart(6,'0')}`;
async function fixture(t,filename=':memory:'){
  const db=openDb(filename),server=createApp(db).listen(0,'127.0.0.1');await new Promise(resolve=>server.once('listening',resolve));
  t.after(async()=>{await new Promise(resolve=>server.close(resolve));db.close();});
  const base=`http://127.0.0.1:${server.address().port}`;
  async function request(url,method='GET',body){const r=await fetch(base+url,{method,headers:{'Content-Type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:r.status,data:await r.json()};}
  const {data:ps}=await request('/api/projects');const p=ps[0].id;
  return {db,server,base,request,p,workspace:async()=> (await request(`/api/projects/${p}/workspace`)).data,importRows:async(rows,name='PL-001')=>request(`/api/projects/${p}/import`,'POST',{packingList:name,rows})};
}
test('400-unit import is repeatable, scoped to a project, and blank cells preserve values',async t=>{
  const f=await fixture(t),rows=Array.from({length:400},(_,i)=>({vin:vin(i+1),brand:'MAXUS',notes:'Keep me',t1:'yes',price:'95.50'}));
  let r=await f.importRows(rows);assert.equal(r.status,201);assert.deepEqual(r.data,{added:400,updated:0});
  r=await f.importRows(rows.map(u=>({vin:u.vin,notes:'',model:'Deliver 9'})));assert.deepEqual(r.data,{added:0,updated:400});
  let w=await f.workspace();assert.equal(w.units.length,400);assert.equal(w.packingLists.length,1);assert.equal(w.units[0].notes,'Keep me');
  const {data:p2}=await f.request('/api/projects','POST',{name:'Next spot',target:100});
  r=await f.request(`/api/projects/${p2.id}/import`,'POST',{packingList:'PL-002',rows:[{vin:vin(1)}]});assert.equal(r.data.added,1);
  const {data:w2}=await f.request(`/api/projects/${p2.id}/workspace`);assert.equal(w2.units.length,1);assert.equal((await f.workspace()).units.length,400);
});
test('Invalid and duplicate imports fail atomically without creating a packing list',async t=>{
  const f=await fixture(t);
  for(const rows of [[{vin:vin(1)},{vin:'BAD'}],[{vin:vin(1)},{vin:vin(1)}],[{vin:vin(1),etd:'2026-02-31T12:00:00Z'}],[{vin:vin(1),t1:'maybe'}],[{vin:vin(1),price:'-1'}]]){
    const r=await f.importRows(rows);assert.equal(r.status,400);const w=await f.workspace();assert.equal(w.units.length,0);assert.equal(w.packingLists.length,0);
  }
});
test('Load assignment enforces project isolation, unique selection, capacity and actual milestones',async t=>{
  const f=await fixture(t);await f.importRows([{vin:vin(1)},{vin:vin(2)},{vin:vin(3)}]);
  let w=await f.workspace(),ids=w.units.map(u=>u.id);
  const {data:l}=await f.request(`/api/projects/${f.p}/loads`,'POST',{reference:'MX-001',capacity:2,origin:'Zeebrugge',destination:'Utrecht',carrier:'Carrier',truck:'AB123',etd:'2026-10-12T08:00:00Z',eta:'2026-10-13T08:00:00Z'});
  const path=`/api/projects/${f.p}/loads/${l.id}`;
  assert.equal((await f.request(path+'/assign','POST',{unitIds:ids})).status,400);
  assert.equal((await f.request(path+'/assign','POST',{unitIds:[ids[0],ids[0]]})).status,400);
  assert.equal((await f.request(path+'/assign','POST',{unitIds:[ids[0],ids[1]]})).status,200);
  w=await f.workspace();assert.equal(w.units[0].status,'scheduled');assert.equal(w.units[0].carrier,'Carrier');assert.equal(w.units[0].destination,'Utrecht');
  assert.equal((await f.request(path,'PATCH',{capacity:1})).status,400);
  assert.equal((await f.request(path+'/milestone','POST',{field:'atd',value:'2026-10-12T09:00:00Z'})).status,200);
  assert.equal((await f.workspace()).units[0].status,'in_transit');
  assert.equal((await f.request(`/api/projects/${f.p}/units/${ids[0]}/unassign`,'POST',{})).status,400);
  assert.equal((await f.request(path+'/milestone','POST',{field:'ata',value:'2026-10-11T09:00:00Z'})).status,400);
  assert.equal((await f.workspace()).units[0].ata,'');
  assert.equal((await f.request(path+'/milestone','POST',{field:'ata',value:'2026-10-13T10:00:00Z'})).status,200);
  w=await f.workspace();assert.equal(w.units.filter(u=>u.status==='delivered').length,2);assert.equal(w.units[2].status,'unscheduled');
  const {data:p2}=await f.request('/api/projects','POST',{name:'Other',target:1});await f.request(`/api/projects/${p2.id}/import`,'POST',{packingList:'Other',rows:[{vin:vin(10)}]});
  const {data:w2}=await f.request(`/api/projects/${p2.id}/workspace`);
  assert.equal((await f.request(path+'/assign','POST',{unitIds:[w2.units[0].id]})).status,404);
});
test('Re-import retains actual dates and load; unit edits and removal are validated',async t=>{
  const f=await fixture(t);await f.importRows([{vin:vin(1),etd:'2026-10-12T08:00:00Z',eta:'2026-10-13T08:00:00Z'}]);
  let w=await f.workspace(),id=w.units[0].id;
  const {data:l}=await f.request(`/api/projects/${f.p}/loads`,'POST',{reference:'L1',capacity:8});
  await f.request(`/api/projects/${f.p}/loads/${l.id}/assign`,'POST',{unitIds:[id]});
  await f.importRows([{vin:vin(1),notes:'Updated notes'}],'PL-002');
  w=await f.workspace();assert.equal(w.units[0].load_id,l.id);assert.equal(w.units[0].packing_list,'PL-002');
  assert.equal((await f.request(`/api/projects/${f.p}/units/${id}`,'PATCH',{etd:'2026-10-14T08:00:00Z',eta:'2026-10-13T08:00:00Z'})).status,400);
  assert.equal((await f.request(`/api/projects/${f.p}/units/${id}/unassign`,'POST',{})).status,200);
  assert.equal((await f.workspace()).units[0].status,'unscheduled');
  await f.request(`/api/projects/${f.p}/units/${id}`,'PATCH',{atd:'2026-10-12T08:00:00Z',ata:'2026-10-13T08:00:00Z'});
  await f.importRows([{vin:vin(1),atd:'',ata:'',brand:'MAXUS'}]);assert.equal((await f.workspace()).units[0].ata,'2026-10-13T08:00:00Z');
});
test('Load updates sync planning without replacing actual dates; existing milestones are preserved',async t=>{
  const f=await fixture(t);await f.importRows([{vin:vin(1)},{vin:vin(2)}]);
  let w=await f.workspace();const ids=w.units.map(u=>u.id);
  const {data:l}=await f.request(`/api/projects/${f.p}/loads`,'POST',{reference:'L1',capacity:8});const path=`/api/projects/${f.p}/loads/${l.id}`;
  await f.request(path+'/assign','POST',{unitIds:ids});
  await f.request(`/api/projects/${f.p}/units/${ids[0]}`,'PATCH',{atd:'2026-10-12T07:00:00Z'});
  const r=await f.request(path+'/milestone','POST',{field:'atd',value:'2026-10-12T08:00:00Z'});assert.equal(r.data.updated,1);
  await f.request(path,'PATCH',{origin:'Antwerp',destination:'Rotterdam',carrier:'New Carrier',etd:'2026-10-12T06:00:00Z',eta:'2026-10-13T10:00:00Z'});
  w=await f.workspace();assert.equal(w.units[0].origin,'Antwerp');assert.equal(w.units[0].carrier,'New Carrier');assert.equal(w.units[0].atd,'2026-10-12T07:00:00Z');
});
test('CSV export includes customer fields and neutralizes spreadsheet formulas',async t=>{
  const f=await fixture(t);await f.importRows([{vin:vin(1),notes:'=HYPERLINK("test")',pol_address:'Port street',pod_address:'Dealer street',price:'95.50',t1:'no'}]);
  const r=await fetch(f.base+`/api/projects/${f.p}/export`),csv=await r.text();assert.equal(r.status,200);
  assert.match(csv,/Price\(EUR\)/);assert.match(csv,/POL-ADDRESS/);assert.match(csv,/Dealer street/);assert.match(csv,/'=HYPERLINK/);assert.equal(csv.split('\r\n').length,2);
});
test('SQLite retains units after the database is closed and reopened',async t=>{
  const dir=mkdtempSync(join(tmpdir(),'ryan-tms-')),filename=join(dir,'db.sqlite');t.after(()=>rmSync(dir,{recursive:true,force:true}));
  let db=openDb(filename);const id=db.prepare('SELECT id FROM projects LIMIT 1').get().id;
  db.prepare('INSERT INTO units(id,project_id,vin,created_at,updated_at) VALUES(?,?,?,?,?)').run('unit-1',id,vin(1),new Date().toISOString(),new Date().toISOString());db.close();
  db=openDb(filename);assert.equal(db.prepare('SELECT vin FROM units').get().vin,vin(1));assert.equal(db.prepare('SELECT count(*) AS n FROM projects').get().n,1);db.close();
});
test('Unique references return a conflict and no duplicate load is created',async t=>{
  const f=await fixture(t);const body={reference:'SAME'};
  assert.equal((await f.request(`/api/projects/${f.p}/loads`,'POST',body)).status,201);
  assert.equal((await f.request(`/api/projects/${f.p}/loads`,'POST',body)).status,409);
  assert.equal((await f.workspace()).loads.length,1);
});
test('Bulk editing fills, sets and clears POL/POD for 400 units while retaining VINs and other fields',async t=>{
  const f=await fixture(t);await f.importRows(Array.from({length:400},(_,i)=>({vin:vin(i+1),origin:i===0?'Keep origin':'',notes:'Keep notes',price:'95.50'})));
  let w=await f.workspace(),ids=w.units.map(u=>u.id);
  let r=await f.request(`/api/projects/${f.p}/units/bulk`,'POST',{unitIds:ids,changes:[{field:'origin',mode:'fill',value:'Kallo'},{field:'destination',mode:'set',value:'Zeebrugge'},{field:'t1',mode:'set',value:'yes'}]});
  assert.equal(r.status,200);assert.equal(r.data.updated,400);w=await f.workspace();assert.equal(w.units[0].origin,'Keep origin');assert.equal(w.units[1].origin,'Kallo');assert.equal(w.units[399].destination,'Zeebrugge');assert.equal(w.units[0].vin,vin(1));assert.equal(w.units[0].notes,'Keep notes');assert.equal(w.units[0].price,'95.50');
  r=await f.request(`/api/projects/${f.p}/units/bulk`,'POST',{unitIds:ids,changes:[{field:'origin',mode:'fill',value:'Other'}]});assert.deepEqual(r.data,{updated:0,unchanged:400});
  r=await f.request(`/api/projects/${f.p}/units/bulk`,'POST',{unitIds:[ids[0]],changes:[{field:'price',mode:'clear'}]});assert.equal(r.status,200);assert.equal((await f.workspace()).units[0].price,'');assert.equal((await f.workspace()).units[1].price,'95.50');
});
test('Bulk edits validate every vehicle before writing and reject cross-project IDs and protected fields',async t=>{
  const f=await fixture(t);await f.importRows([{vin:vin(1)},{vin:vin(2),atd:'2026-10-13T08:00:00Z'}]);let w=await f.workspace(),ids=w.units.map(u=>u.id);
  const endpoint=`/api/projects/${f.p}/units/bulk`;
  assert.equal((await f.request(endpoint,'POST',{unitIds:ids,changes:[{field:'ata',mode:'set',value:'2026-10-12T08:00:00Z'}]})).status,400);assert.ok((await f.workspace()).units.every(u=>!u.ata));
  for(const changes of [[{field:'vin',mode:'set',value:vin(3)}],[{field:'load_id',mode:'set',value:'fake'}],[{field:'origin',mode:'set',value:''}],[{field:'t1',mode:'set',value:'maybe'}],[{field:'origin',mode:'set',value:'Kallo'},{field:'origin',mode:'set',value:'Other'}]])assert.equal((await f.request(endpoint,'POST',{unitIds:ids,changes})).status,400);
  const {data:p2}=await f.request('/api/projects','POST',{name:'Other project'});await f.request(`/api/projects/${p2.id}/import`,'POST',{packingList:'Other',rows:[{vin:vin(10)}]});const {data:w2}=await f.request(`/api/projects/${p2.id}/workspace`);
  assert.equal((await f.request(endpoint,'POST',{unitIds:[ids[0],w2.units[0].id],changes:[{field:'origin',mode:'set',value:'Kallo'}]})).status,404);assert.equal((await f.workspace()).units[0].origin,'');
});

test('Packing-list order survives re-imports; 200 VINs can be assigned independently of load planning',async t=>{
  const f=await fixture(t),rows=Array.from({length:400},(_,i)=>({vin:vin(400-i),notes:'Original note'}));
  await f.importRows(rows);let w=await f.workspace();assert.deepEqual(w.units.map(u=>u.vin),rows.map(u=>u.vin));
  await f.importRows([...rows].reverse());w=await f.workspace();assert.deepEqual(w.units.map(u=>u.vin),rows.map(u=>u.vin));
  const {data:c}=await f.request(`/api/projects/${f.p}/carriers`,'POST',{name:'First Carrier'});
  const path=`/api/projects/${f.p}/carriers/${c.id}`;
  assert.equal((await f.request(path+'/assign','POST',{unitIds:w.units.slice(0,200).map(u=>u.id)})).data.assigned,200);
  w=await f.workspace();assert.ok(w.units.slice(0,200).every(u=>u.carrier==='First Carrier'&&u.status==='unscheduled'&&!u.load_id));assert.ok(w.units.slice(200).every(u=>!u.carrier));
  assert.equal(w.carriers.length,1);
  assert.equal((await f.request(`/api/projects/${f.p}/carriers`,'POST',{name:'first carrier'})).data.id,c.id);
  const {data:p2}=await f.request('/api/projects','POST',{name:'Other'});
  assert.equal((await f.request(`/api/projects/${p2.id}/carriers/${c.id}/assign`,'POST',{unitIds:[w.units[0].id]})).status,404);
});

async function carrierFixture(t,count=4){
  const f=await fixture(t);await f.importRows(Array.from({length:count},(_,i)=>({vin:vin(i+1),notes:'Keep note',origin:'Kallo',destination:'Zeebrugge'})));
  const {data:c}=await f.request(`/api/projects/${f.p}/carriers`,'POST',{name:'Carrier A'});const w=await f.workspace();
  const path=`/api/projects/${f.p}/carriers/${c.id}`;await f.request(path+'/assign','POST',{unitIds:w.units.map(u=>u.id)});
  const preview=body=>f.request(path+'/updates/preview','POST',body);
  async function apply(body){const r=await preview(body);assert.equal(r.status,200,JSON.stringify(r.data));return f.request(path+'/updates','POST',{...body,snapshot:r.data.snapshot});}
  return {...f,c,path,preview,apply};
}
test('Carrier sheets create gap loads, reuse them on repeated pastes, preserve blanks, and update all four milestones',async t=>{
  const f=await carrierFixture(t);
  let body={groupLoads:true,rows:[1,2,3,4].map((i)=>({vin:vin(i),group:i<3?'0':'1',etd:'2026-10-12T06:00:00Z',eta:'2026-10-13T10:00:00Z'}))};
  let r=await f.preview(body);assert.equal(r.data.counts.loadsCreated,2);assert.equal(r.data.counts.changed,4);assert.ok((await f.workspace()).units.every(u=>!u.etd));
  r=await f.apply(body);assert.equal(r.status,200);let w=await f.workspace();const loadIds=w.units.map(u=>u.load_id);assert.equal(w.loads.length,2);assert.ok(w.units.every(u=>u.status==='scheduled'&&u.packing_list==='PL-001'&&u.notes==='Keep note'));
  assert.equal((await f.apply(body)).data.changed,0);w=await f.workspace();assert.equal(w.loads.length,2);assert.deepEqual(w.units.map(u=>u.load_id),loadIds);assert.equal(w.carrierUpdates.length,2);assert.ok(w.carriers[0].last_update);
  body={...body,rows:body.rows.map(r=>({...r,etd:'',eta:'2026-10-14T10:00:00Z',atd:'2026-10-12T07:00:00Z',ata:'2026-10-14T09:00:00Z',notes:''}))};
  assert.equal((await f.apply(body)).status,200);w=await f.workspace();assert.equal(w.units.length,4);assert.ok(w.units.every(u=>u.status==='delivered'&&u.etd==='2026-10-12T06:00:00Z'&&u.notes==='Keep note'));assert.ok(w.loads.every(l=>l.eta==='2026-10-14T10:00:00Z'));
  // A daily paste may contain only one VIN from a saved departed load.
  assert.equal((await f.apply({groupLoads:true,rows:[{vin:vin(1),group:'0',eta:'2026-10-15T10:00:00Z'}]})).status,200);
  w=await f.workspace();assert.deepEqual(w.units.map(u=>u.load_id),loadIds);assert.equal(w.units[1].eta,'2026-10-14T10:00:00Z');assert.equal(w.loads.find(l=>l.id===loadIds[0]).eta,'');
});
test('Carrier update validation is atomic, isolates carriers, and rejects stale previews',async t=>{
  const f=await carrierFixture(t);const w=await f.workspace();const {data:b}=await f.request(`/api/projects/${f.p}/carriers`,'POST',{name:'Carrier B'});
  await f.request(`/api/projects/${f.p}/carriers/${b.id}/assign`,'POST',{unitIds:[w.units[3].id]});
  for(const rows of [[{vin:vin(1),notes:'Changed'},{vin:vin(4)}],[{vin:vin(1)},{vin:vin(99)}],[{vin:vin(1)},{vin:vin(1)}],[{vin:vin(1),carrier:'Carrier B'}],[{vin:vin(1),atd:'2026-10-13T08:00:00Z',ata:'2026-10-12T08:00:00Z'}]]){
    const r=await f.preview({groupLoads:false,rows});assert.equal(r.status,400);assert.equal((await f.workspace()).units[0].notes,'Keep note');assert.equal((await f.workspace()).carrierUpdates.length,0);
  }
  const body={groupLoads:false,rows:[{vin:vin(1),notes:'Sheet update'}]},review=await f.preview(body);
  await f.request(`/api/projects/${f.p}/units/${w.units[0].id}`,'PATCH',{notes:'Newer manual update'});
  assert.equal((await f.request(f.path+'/updates','POST',{...body,snapshot:review.data.snapshot})).status,409);assert.equal((await f.workspace()).units[0].notes,'Newer manual update');
  assert.equal((await f.apply(body)).status,200);assert.equal((await f.workspace()).units[0].notes,'Sheet update');
});
test('Changing blank-row groups repartitions planned loads but never moves departed VINs',async t=>{
  const f=await carrierFixture(t);
  await f.apply({groupLoads:true,rows:[1,2,3,4].map(i=>({vin:vin(i),group:'0'}))});
  const split={groupLoads:true,rows:[1,2,3,4].map(i=>({vin:vin(i),group:i<3?'0':'1'}))};
  assert.equal((await f.apply(split)).data.loadsCreated,2);let w=await f.workspace();assert.equal(w.units[0].load_id,w.units[1].load_id);assert.notEqual(w.units[0].load_id,w.units[2].load_id);
  const ids=w.units.map(u=>u.load_id);await f.request(`/api/projects/${f.p}/units/${w.units[0].id}`,'PATCH',{atd:'2026-10-12T07:00:00Z'});
  const regroup={groupLoads:true,rows:[1,2,3,4].map(i=>({vin:vin(i),group:i%2?'0':'1'}))};
  assert.equal((await f.preview(regroup)).status,400);w=await f.workspace();assert.deepEqual(w.units.map(u=>u.load_id),ids);
  assert.equal((await f.apply({...regroup,groupLoads:false})).status,200);assert.deepEqual((await f.workspace()).units.map(u=>u.load_id),ids);
  const {data:b}=await f.request(`/api/projects/${f.p}/carriers`,'POST',{name:'Carrier B'});assert.equal((await f.request(`/api/projects/${f.p}/carriers/${b.id}/assign`,'POST',{unitIds:[w.units[1].id]})).status,400);
});
test('Explicit carrier load references enforce capacity and carrier ownership',async t=>{
  const f=await carrierFixture(t);
  const {data:l}=await f.request(`/api/projects/${f.p}/loads`,'POST',{reference:'TRUCK-01',carrier:'Carrier A',capacity:2});
  assert.equal((await f.preview({groupLoads:true,rows:[1,2,3].map(i=>({vin:vin(i),load_reference:'TRUCK-01'}))})).status,400);
  assert.equal((await f.apply({groupLoads:true,rows:[1,2].map(i=>({vin:vin(i),load_reference:'TRUCK-01'}))})).status,200);
  assert.ok((await f.workspace()).units.slice(0,2).every(u=>u.load_id===l.id));
  await f.request(`/api/projects/${f.p}/loads`,'POST',{reference:'OTHER',carrier:'Carrier B'});
  assert.equal((await f.preview({groupLoads:true,rows:[{vin:vin(3),load_reference:'OTHER'}]})).status,400);
});

test('A later gap can establish missing load membership without losing recorded actual milestones',async t=>{
  const f=await carrierFixture(t,2);
  await f.apply({groupLoads:false,rows:[{vin:vin(1),atd:'2026-10-12T07:00:00Z',ata:'2026-10-13T07:00:00Z'}]});
  assert.equal((await f.workspace()).units[0].load_id,null);
  const r=await f.apply({groupLoads:true,rows:[{vin:vin(1),group:'0'},{vin:vin(2),group:'1'}]});assert.equal(r.status,200);assert.equal(r.data.loadsCreated,2);
  const w=await f.workspace();assert.ok(w.units[0].load_id);assert.equal(w.units[0].status,'delivered');assert.equal(w.units[0].ata,'2026-10-13T07:00:00Z');
});

test('A full sheet repairs an old oversized remainder load, keeps planned loads stable, and tracks pool-to-load changes',async t=>{
  const f=await carrierFixture(t,20);
  // Simulate the previous version interpreting the whole final remainder as a load.
  await f.apply({groupLoads:true,rows:Array.from({length:20},(_,i)=>({vin:vin(i+1),group:i<6?'0':'1',etd:i<12?'2026-10-07T06:00:00Z':''}))});
  let w=await f.workspace();const first=w.units[0].load_id,last=w.units[6].load_id;
  const body={groupLoads:true,rows:Array.from({length:20},(_,i)=>i<12?{vin:vin(i+1),group:i<6?'0':'1'}:{vin:vin(i+1),load_action:'pool'})};
  const r=await f.apply(body);assert.equal(r.status,200);assert.equal(r.data.built,12);assert.equal(r.data.pool,8);assert.equal(r.data.loadsReleased,8);
  w=await f.workspace();assert.ok(w.units.slice(12).every(u=>!u.load_id&&u.status==='unscheduled'));assert.equal(w.units[0].load_id,first);assert.equal(w.units[6].load_id,last);assert.equal(w.loads.find(l=>l.id===last).capacity,6);
  assert.equal((await f.apply(body)).data.changed,0);
  const next={...body,rows:body.rows.map((r,i)=>i>=12&&i<18?{vin:r.vin,group:'2',etd:'2026-10-08T06:00:00Z',eta:'2026-10-08T08:00:00Z'}:r)};
  assert.equal((await f.apply(next)).data.loadsCreated,1);assert.equal((await f.workspace()).units.filter(u=>!u.load_id).length,2);assert.equal((await f.apply(next)).data.changed,0);
});

test('Returning a planned VIN to the pool preserves its dates and carrier; actual loads remain protected',async t=>{
  const f=await carrierFixture(t,2);await f.apply({groupLoads:true,rows:[{vin:vin(1),group:'0',etd:'2026-10-07T06:00:00Z'},{vin:vin(2),group:'1',atd:'2026-10-07T07:00:00Z'}]});
  const r=await f.apply({groupLoads:true,rows:[{vin:vin(1),load_action:'pool'},{vin:vin(2),load_action:'pool',eta:'2026-10-07T10:00:00Z'}]});
  assert.equal(r.status,200);assert.equal(r.data.loadsReleased,1);assert.equal(r.data.pool,1);const w=await f.workspace();assert.equal(w.units[0].load_id,null);assert.equal(w.units[0].etd,'2026-10-07T06:00:00Z');assert.equal(w.units[0].carrier,'Carrier A');assert.ok(w.units[1].load_id);assert.equal(w.units[1].eta,'2026-10-07T10:00:00Z');
});

test('A partial paste cannot grow an inferred load beyond the 500-VIN limit',async t=>{
  const f=await carrierFixture(t,501);
  await f.apply({groupLoads:true,rows:Array.from({length:500},(_,i)=>({vin:vin(i+1),group:'0'}))});
  const r=await f.preview({groupLoads:true,rows:[{vin:vin(1),group:'0'},{vin:vin(501),group:'0'}]});assert.equal(r.status,400);assert.match(r.data.error,/maximum of 500/);
  const w=await f.workspace();assert.equal(w.units.filter(u=>u.load_id).length,500);assert.equal(w.loads[0].capacity,500);
});

test('Readiness is a separate reference stage, with actual milestones taking precedence',async t=>{
  const f=await fixture(t);await f.importRows([{vin:vin(1),truck:'TEST-01'},{vin:vin(2),reference:'Appointment-2'},{vin:vin(3),reference:'Appointment-3',atd:'2026-10-10T08:00:00Z'},{vin:vin(4),reference:'Appointment-4',ata:'2026-10-11T08:00:00Z'}]);
  assert.deepEqual((await f.workspace()).units.map(u=>u.status),['scheduled','ready','in_transit','delivered']);
  const {data:l}=await f.request(`/api/projects/${f.p}/loads`,'POST',{reference:'Generated reference'});
  await f.request(`/api/projects/${f.p}/loads/${l.id}/assign`,'POST',{unitIds:[(await f.workspace()).units[0].id]});
  assert.equal((await f.workspace()).units[0].status,'scheduled');
});

test('Project rates fill or replace selected bases without double counting, and future imports inherit defaults',async t=>{
  const {financeReport}=await import('../server/finance-report.js');const f=await fixture(t);
  await f.importRows([{vin:vin(1),price:'90'},{vin:vin(2),price:'100',revenue:'120'}]);
  const {data:l}=await f.request(`/api/projects/${f.p}/loads`,'POST',{reference:'Priced load'});
  await f.request(`/api/projects/${f.p}/loads/${l.id}/assign`,'POST',{unitIds:(await f.workspace()).units.map(u=>u.id)});
  const rates={cost_basis:'load',revenue_basis:'unit',unit_cost:'95',load_cost:'500',unit_revenue:'300',load_revenue:'800'};
  const path=`/api/projects/${f.p}/rates`;assert.equal((await f.request(path,'POST',{rates,apply:'fill'})).status,200);
  let w=await f.workspace();assert.deepEqual(w.units.map(u=>u.price),['90','100']);assert.deepEqual(w.units.map(u=>u.revenue),['300','120']);assert.equal(w.loads[0].cost,'500');
  let report=financeReport(w.project,w.loads,w.units);assert.equal(report.totals.cost,50000);assert.equal(report.totals.revenue,42000);assert.equal(report.totals.margin,-8000);
  await f.request(path,'POST',{rates,apply:'replace'});w=await f.workspace();report=financeReport(w.project,w.loads,w.units);assert.equal(report.totals.revenue,60000);assert.equal(report.totals.margin,10000);
  await f.importRows([{vin:vin(3)}]);w=await f.workspace();assert.equal(w.units[2].price,'95');assert.equal(w.units[2].revenue,'300');
  const fresh=await f.request(`/api/projects/${f.p}/loads`,'POST',{reference:'Next priced load'});assert.equal(fresh.data.cost,'500');assert.equal(fresh.data.revenue,'800');
  const before=await f.workspace();assert.equal((await f.request(path,'POST',{rates:{...rates,load_cost:'-1'},apply:'replace'})).status,400);assert.deepEqual(await f.workspace(),before);
  assert.equal((await f.request(`/api/projects/${f.p}/loads/prices`,'POST',{loadIds:[l.id],mode:'replace',cost:'0',revenue:'900.99'})).status,200);
  w=await f.workspace();assert.equal(w.loads.find(x=>x.id===l.id).cost,'0');assert.equal(w.loads.find(x=>x.id===l.id).revenue,'900.99');
  const {data:other}=await f.request('/api/projects','POST',{name:'Other rates'});
  assert.equal((await f.request(`/api/projects/${other.id}/loads/prices`,'POST',{loadIds:[l.id],mode:'replace',cost:'99'})).status,404);
  assert.equal((await f.request(`/api/projects/${f.p}/loads/prices`,'POST',{loadIds:[l.id],mode:'fill',cost:'99'})).data.updated,0);
});

test('Carrier date changes preview VIN/load risks, persist alerts, ignore equal instants, and resolve within project',async t=>{
  const f=await fixture(t);await f.importRows([1,2,3].map(i=>({vin:vin(i)})));
  const {data:c}=await f.request(`/api/projects/${f.p}/carriers`,'POST',{name:'Risk test carrier'});
  await f.request(`/api/projects/${f.p}/carriers/${c.id}/assign`,'POST',{unitIds:(await f.workspace()).units.map(u=>u.id)});
  const rates={cost_basis:'load',revenue_basis:'load',unit_cost:'',unit_revenue:'',load_cost:'750',load_revenue:'950'};
  await f.request(`/api/projects/${f.p}/rates`,'POST',{rates,apply:'none'});
  const path=`/api/projects/${f.p}/carriers/${c.id}/updates`,body={groupLoads:true,rows:[1,2].map(i=>({vin:vin(i),group:'1',etd:'2026-10-12T08:00:00Z',eta:'2026-10-13T08:00:00Z'}))};
  let preview=(await f.request(path+'/preview','POST',body)).data;assert.deepEqual(preview.risks,[]);
  assert.equal((await f.request(path,'POST',{...body,snapshot:preview.snapshot})).status,200);
  let w=await f.workspace();assert.equal(w.loads[0].cost,'750');assert.equal(w.loads[0].revenue,'950');
  const changed={...body,rows:body.rows.map(r=>({...r,reference:'Booking 123',etd:'2026-10-14T08:00:00Z',eta:'2026-10-15T08:00:00Z'}))};
  preview=(await f.request(path+'/preview','POST',changed)).data;assert.equal(preview.risks.length,4);assert.equal(preview.risks[0].deltaMinutes,2880);assert.equal(preview.risks[0].load_reference,w.loads[0].reference);
  await f.request(path,'POST',{...changed,snapshot:preview.snapshot});w=await f.workspace();assert.equal(w.scheduleAlerts.length,4);assert.equal(w.units[0].status,'ready');
  preview=(await f.request(path+'/preview','POST',changed)).data;assert.deepEqual(preview.risks,[]);await f.request(path,'POST',{...changed,snapshot:preview.snapshot});assert.equal((await f.workspace()).scheduleAlerts.length,4);
  const sameTime={...changed,rows:changed.rows.map(r=>({...r,etd:'2026-10-14T10:00:00+02:00'}))};assert.deepEqual((await f.request(path+'/preview','POST',sameTime)).data.risks,[]);
  const {data:other}=await f.request('/api/projects','POST',{name:'Other alerts'});
  assert.equal((await f.request(`/api/projects/${other.id}/alerts/resolve`,'POST',{alertIds:[w.scheduleAlerts[0].id]})).status,404);
  assert.equal((await f.request(`/api/projects/${f.p}/alerts/resolve`,'POST',{alertIds:w.scheduleAlerts.map(a=>a.id)})).status,200);
  assert.equal((await f.workspace()).scheduleAlerts.filter(a=>!a.resolved_at).length,0);
});

test('Operational totals exclude empty inferred history and keep mixed-date and partially departed loads accurate',async()=>{
  const {loadStatus,operationalLoads}=await import('../server/operations.js');
  const loads=[{id:'a',reference:'Manual draft',notes:''},{id:'b',reference:'Current inferred',notes:'Created from carrier sheet groups'},{id:'c',reference:'Old inferred',notes:'Created from carrier sheet groups'}];
  const units=[{load_id:'b',reference:'Booking',atd:''},{load_id:'b',truck:'TEST-01'}];
  assert.equal(operationalLoads(loads,units).length,2);assert.equal(loadStatus(loads[1],units),'scheduled');
  units[1].reference='Booking';assert.equal(loadStatus(loads[1],units),'ready');units[0].atd='2026-10-12T08:00:00Z';assert.equal(loadStatus(loads[1],units),'in_transit');
});

test('Project settings rename and change estimates or follow unique packing-list totals without touching records',async t=>{
  const f=await fixture(t);await f.importRows([{vin:vin(1),notes:'Preserve',price:'95.50'},{vin:vin(2)}]);
  const before=await f.workspace(),path=`/api/projects/${f.p}`;
  assert.equal(before.project.target,400);assert.equal(before.project.estimated_target,400);assert.equal(before.project.volume_mode,'estimate');
  let r=await f.request(path,'PATCH',{name:'Renamed spot',customer:'New brand',target:350});assert.equal(r.status,200);assert.equal(r.data.name,'Renamed spot');assert.equal(r.data.target,350);
  assert.deepEqual((await f.workspace()).units,before.units);
  r=await f.request(path,'PATCH',{volume_mode:'packing_list'});assert.equal(r.data.target,2);assert.equal(r.data.estimated_target,350);assert.equal(r.data.imported_count,2);
  await f.importRows([{vin:vin(1),notes:'Preserve'},{vin:vin(3)}],'Second packing list');let w=await f.workspace();assert.equal(w.project.target,3);assert.equal(w.packingLists.length,2);
  assert.equal((await f.request('/api/projects')).data.find(p=>p.id===f.p).target,3);
  await f.importRows([{vin:vin(1)}],'Second packing list');w=await f.workspace();assert.equal(w.project.target,3);assert.equal(w.units.length,3);
  r=await f.request(path,'PATCH',{volume_mode:'estimate'});assert.equal(r.data.target,350);
  const stable=await f.workspace();for(const patch of [{name:''},{name:'No partial rename',target:-1},{target:1.5},{volume_mode:'invalid'}])assert.equal((await f.request(path,'PATCH',patch)).status,400);
  assert.deepEqual(await f.workspace(),stable);assert.equal((await f.request('/api/projects/missing','PATCH',{target:5})).status,404);
  const {data:empty}=await f.request('/api/projects','POST',{name:'Zero imported units'});assert.equal((await f.request(`/api/projects/${empty.id}`,'PATCH',{volume_mode:'packing_list'})).data.target,0);
});

test('Deleting a populated project requires its current name, removes all dependent records, and preserves other projects',async t=>{
  const f=await fixture(t);await f.importRows([{vin:vin(1),carrier:'Delete carrier'},{vin:vin(2),carrier:'Delete carrier'}]);
  let w=await f.workspace();const c=w.carriers[0],path=`/api/projects/${f.p}/carriers/${c.id}/updates`;
  const body={groupLoads:true,rows:[1,2].map(i=>({vin:vin(i),group:'one',etd:'2026-10-12T08:00:00Z',eta:'2026-10-13T08:00:00Z'}))};
  let review=(await f.request(path+'/preview','POST',body)).data;await f.request(path,'POST',{...body,snapshot:review.snapshot});
  const changed={...body,rows:body.rows.map(r=>({...r,eta:'2026-10-14T08:00:00Z'}))};review=(await f.request(path+'/preview','POST',changed)).data;await f.request(path,'POST',{...changed,snapshot:review.snapshot});
  const {data:other}=await f.request('/api/projects','POST',{name:'Keep other project'});await f.request(`/api/projects/${other.id}/import`,'POST',{packingList:'Keep list',rows:[{vin:vin(1),carrier:'Keep carrier',price:'25'}]});
  const otherBefore=(await f.request(`/api/projects/${other.id}/workspace`)).data;
  w=await f.workspace();assert.equal(w.scheduleAlerts.length,2);assert.equal(w.carrierUpdates.length,2);assert.equal(w.loads.length,1);
  for(const body of [undefined,{}, {confirmName:'wrong'}])assert.equal((await f.request(`/api/projects/${f.p}`,'DELETE',body)).status,400);
  assert.deepEqual(await f.workspace(),w);
  await f.request(`/api/projects/${f.p}`,'PATCH',{name:'New deletion name'});assert.equal((await f.request(`/api/projects/${f.p}`,'DELETE',{confirmName:w.project.name})).status,400);
  assert.equal((await f.request(`/api/projects/${f.p}`,'DELETE',{confirmName:'New deletion name'})).status,200);
  for(const table of ['schedule_alerts','events','carrier_updates','units','loads','packing_lists','carriers'])assert.equal(f.db.prepare(`SELECT count(*) AS n FROM ${table} WHERE project_id=?`).get(f.p).n,0,table);
  assert.equal((await f.request(`/api/projects/${f.p}/workspace`)).status,404);assert.deepEqual((await f.request(`/api/projects/${other.id}/workspace`)).data,otherBefore);
});

test('Deleting the last project leaves an empty workspace across database restarts, and a new project can be created',async t=>{
  const directory=mkdtempSync(join(tmpdir(),'tms-delete-')),filename=join(directory,'tms.sqlite');t.after(()=>rmSync(directory,{recursive:true,force:true}));
  let db=openDb(filename),server=createApp(db).listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));
  const base=`http://127.0.0.1:${server.address().port}`,p=db.prepare('SELECT * FROM projects').get();
  const response=await fetch(base+`/api/projects/${p.id}`,{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirmName:p.name})});assert.equal(response.status,200);
  assert.deepEqual(await (await fetch(base+'/api/projects')).json(),[]);await new Promise(r=>server.close(r));db.close();
  db=openDb(filename);assert.equal(db.prepare('SELECT count(*) AS n FROM projects').get().n,0);
  server=createApp(db).listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));
  try{const r=await fetch(`http://127.0.0.1:${server.address().port}/api/projects`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:'New project after deletion',target:250})});assert.equal(r.status,201);assert.equal((await r.json()).target,250);}finally{await new Promise(r=>server.close(r));db.close();}
});
